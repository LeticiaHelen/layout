<html>
<head>
  <!-- Standard Meta -->
  <meta charset="utf-8">

  <!-- Site Properties -->
  <title>QrList</title>
  <link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
  <link rel="stylesheet" type="text/css" href="../../css/style.css">
</head>

<nav>
<div class="ui inverted menu">
  <a class="active item">
    Home
  </a>
  <a class="item">
    Messages
  </a>
  <a class="item">
    Friends
  </a> 
  <div class="right menu">
    <a class="ui item">
      Logout
    </a>
  </div>
</div>
</nav>