<html>
<head>

    <link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="../../css/style.css">
    <!-- Standard Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

    <!-- Site Properties -->
    <title>QrList</title>
    <script
        src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
        crossorigin="anonymous"></script>
    <script src="../../semantic/dist/semantic.min.js"></script>
    <!--    VER DA ONDE É ESSE ASSESTS-->
    <!--    <script src="assets/library/jquery.min.js"></script>-->
    <script src="../../semantic/dist/components/visibility.js"></script>
    <script src="../../semantic/dist/components/sidebar.js"></script>
    <script src="../../semantic/dist/components/transition.js"></script>
    <script>
        $(document)
            .ready(function() {

                // fix menu when passed
                $('.masthead')
                    .visibility({
                        once: false,
                        onBottomPassed: function() {
                            $('.fixed.menu').transition('fade in');
                        },
                        onBottomPassedReverse: function() {
                            $('.fixed.menu').transition('fade out');
                        }
                    })
                ;

                // create sidebar and attach to menu open
                $('.ui.sidebar')
                    .sidebar('attach events', '.toc.item')
                ;

            })
        ;
    </script>
    <link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css">
</head>

    <body class="pushable">

        <!-- Following Menu -->
        <div class="ui large top fixed menu transition hidden">
            <div class="ui container">
                <a class="active item" href="#">Home</a>
                <a class="item">Mercados</a>
                <a class="item">Company</a>
                <a class="item">Careers</a>
                <div class="right menu">
                    <div class="item">
                        <a class="ui" href="#">Log in</a>
                    </div>
                    <div class="item">
                        <a class="ui" href="http://localhost/COPIA_POO/app/controllers/usuario.php?acao=cadastrar_usuario">Sign Up</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Page Contents -->
        <div class="pusher">

            <div class="ui inverted vertical masthead center aligned segment bg_primarioIndex ">
                <div class="ui text container letraIndex">
                    <!--                    LOGO DO QRLIST                 -->
                    <!--            <img src="../imagens/QrList_preto.png">-->
                    <h1 class="ui inverted header">QrList</h1>
                    <h2>Um jeito inovador de fazer suas listas de compras.</h2>
                    <div class="item ">
                        <a class="ui inverted button" href="#">Log in</a>
                        <a class="ui inverted button" href="http://localhost/COPIA_POO/app/controllers/usuario.php?acao=cadastrar_usuario">Sign Up</a>
                    </div>
                </div>
            </div>

            <div class="ui vertical stripe segment fundoIndex">
                <div class="ui middle aligned stackable grid container espacamento">
                    <div class="row">
                        <div class="eight wide column">
                            <h3 class="ui header">FAÇA SUAS LISTAS DE COMPRAS ONLINE!</h3>
                            <p>O QrList é um site que possibilita a confecção de suas listas de compras de forma online e inteiramente gratuita!</p>
                            <h3 class="ui header">COMO FAZER MINHA PRIMEIRA LISTA DE COMPRAS?</h3>
                            <p> Primeiro você escolhe o mercado que deseja fazer suas compras</p>
                            <p> Depois tem acesso aos preços e aos produtos do mercado, e apartir daí é só adicionar os produtos em sua lista!</p>
                            <p> Quando terminar de adicionar todos os produtos desejados, é só clicar em "Finalizar", e prontinho, lista criada! </p>
                        </div>
                        <div class="six wide right floated column">
                            <img src="../../imagens/listaaa.png" class="ui large bordered rounded image">
                        </div>
                    </div>
                </div>
            </div>

            <div class="ui vertical stripe segment fundoIndex">
                <div class="ui middle aligned stackable grid container espacamento">
                    <div class="row">
                        <div class="six wide left floated column">
                            <img src="../../imagens/ligacao.png" class="ui large bordered rounded image">
                        </div>
                        <div class="eight wide column">
                            <h3 class="ui header">VÁRIAS OPÇÕES</h3>
                            <p>O QrList conta VÁRIAVEL mercados parceiros. Para ver quais estabelecimentos fazem parte desse grupo clique aqui(link).</p>
                        </div>

                    </div>
                </div>
            </div>

            <div class="ui vertical stripe segment fundoIndex">
                <div class="ui middle aligned stackable grid container espacamento">
                    <div class="row">
                        <div class="eight wide column">
                            <h3 class="ui header">We Help Companies and Companions</h3>
                            <p>We can give your company superpowers to do things that they never thought possible. Let us delight your customers and empower your needs...through pure data analytics.</p>
                            <h3 class="ui header">We Make Bananas That Can Dance</h3>
                            <p>Yes that's right, you thought it was the stuff of dreams, but even bananas can be bioengineered.</p>
                        </div>
                        <div class="six wide right floated column">
                            <img src="../../imagens/carrinho.png" class="ui large bordered rounded image">
                        </div>
                    </div>
                </div>
            </div>

            <div class="ui vertical stripe segment fundoIndex">
                <div class="ui text container">
                    <h3 class="ui header">Breaking The Grid, Grabs Your Attention</h3>
                    <p>Instead of focusing on content creation and hard work, we have learned how to master the art of doing nothing by providing massive amounts of whitespace and generic content that can seem massive, monolithic and worth your attention.</p>
                    <a class="ui large button">Read More</a>
                    <h4 class="ui horizontal header divider">
                        <a href="#">Case Studies</a>
                    </h4>
                    <h3 class="ui header">Did We Tell You About Our Bananas?</h3>
                    <p>Yes I know you probably disregarded the earlier boasts as non-sequitur filler content, but its really true. It took years of gene splicing and combinatory DNA research, but our bananas can really dance.</p>
                    <a class="ui large button">I'm Still Quite Interested</a>
                </div>
            </div>
<?php include "footer.php"  ?>