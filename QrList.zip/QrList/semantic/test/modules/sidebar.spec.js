describe("UI Rating", function() {

  moduleTests({
    module  : 'rating',
    element : '.ui.rating'
  });

});